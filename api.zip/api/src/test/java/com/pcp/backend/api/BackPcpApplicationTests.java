package com.pcp.backend.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackPcpApplicationTests {

	@Test
	void contextLoads() {
	}

}
