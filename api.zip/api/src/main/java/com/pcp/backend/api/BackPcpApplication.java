package com.pcp.backend.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackPcpApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackPcpApplication.class, args);
	}

}
